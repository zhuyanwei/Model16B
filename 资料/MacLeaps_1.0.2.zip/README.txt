Contents
========

 1. About MacLeaps
 2. Requirements
 3. Usage
 4. Results
 5. Examples
 6. Known Issues



About MacLeaps
==============
Using machine learning methods, GWAS data can be analysed for more complex
relations between single nucleotide polymorphisms (SNPs) and diseases than
simple statistical methods that look at each SNP separately. However, this often
requires the use of several tools and the necessity of intensive data conversion
and user interaction.

We developed MacLeaps as an automated pipeline that uses state-of-the-art
machine learning algorithms to create a disease risk model based on a given GWAS
SNP data set and assesses its predictive performance for unseen data sets.
The pipeline can either use a first data set for training the model and a second
for validation, or perform a nested k-fold cross-validation on a single data
set.

For each training set a basic case/control association analysis is performed to
estimate the association between each single SNP and the phenotype. Using this
information the data set is filtered to create multiple subsets that contain
only SNPs below a certain p-value threshold and for each subset a model is
trained using a support vector machine (LIBSVM: linear and RBF kernel) and
tested on its corresponding validation subset.

The prediction performance is measured as the area under the ROC curve (AUC) and
visualized in a plot showing average AUC and standard deviation for each p-value
threshold. The only required input for this pipeline is the SNP data, all other
parameters use default values, but can be specified by the user, if wanted.

During the whole process, the pipeline takes care of the necessary conversions
between different data formats and stores all intermediate data and final
results to allow for subsequent analysis of single steps. Additionally, if a
second analysis is performed on the same data set with different parameters,
e.g., adding another p-value threshold, the pipeline will not repeat steps to
create data that is still valid.



Requirements
============

Software:
 - Java 6
   http://www.java.com/ 
 - PLINK:
   http://pngu.mgh.harvard.edu/~purcell/plink/download.shtml#download

 NOTE: You need to download the binary executables for your specific operating
 system.
 
Hardware:
The bigger the GWAS data set you want to analyze, the more physical memory you
need and the more memory you need to provide to the Java Virtual Machine (JVM).

You can specify the amount of memory the JVM may use using the "-Xmx" parameter,
e.g.
     java -Xmx2g [rest of arguments]
     
will grant 2 gigabytes of RAM to the JVM. Note that if you're using a 32-bit
operating system, this might be limited to even less.
 


Usage
=====

java -jar MacLeaps.jar [options]

Starts the program MacLeaps. If no options are given, the GUI is started by
default.

Option summary:

--help, -?    Lists all available options.

= External Tools Options

-pp <path>    Path to directory with the PLINK executable.


= SVMPipeline Options

== General pipeline parameters

-p <File>     Path and name of .ped or .bed file (e.g. /tmp/data.ped).
-s <String>   Basename(s) of the study, used as prefix for all generated files.
-mo <File>    Path and name of the model .bim file (e.g. /tmp/extmodel.bim).
-sf <File>    File containing individuals of study A (only for cross-study validation).
-o <File>     Path for output files (default: current working directory). 
-k <Integer>  No. of folds in the outer cross-validation. 
-t            Use the top 3, 10, 30, ... SNPs as cut-off instead of p-values. 
-cm           Train a model, but don't validate. 
-m            Minimalistic mode (doesn't create additional .bed or .ped files). 
-nt <Integer> No. of threads (default: no. of processors). 
-v            Verbose debug output.
 
 
== SVM RBF Parameters

-dr           Perform additional SVM analysis using radial basis function (RBF) kernel. 
-gr <Integer> No. of repeats for parameter optimization. 
-gf <Integer> No. of folds for parameter optimization. 
-n            Normalize features before analysis (mean=0, stdev=1). 
-ht           Use experimental heuristic for C and Gamma for the RBF kernel (requires normalization). 


== Simulation options

--sim-file <File>          File containing simulation parameters (OPTIONAL).
--sim-ncases <Integer>     No. of simulated cases (only for simulation data). 
--sim-ncontrols <Integer>  No. of simulated controls (only for simulation data). 
--sim-prevalence <Float>   Simulated disease prevalence (only for simulation data). 
--trim                     Trim PLINK file during analysis (only for simulation data). 


= Default analysis options

--default-plinkfile-directory <File>  Default PLINK file directory. 
--default-output-directory <File>     Default output directory.
--default-folds <Integer>             Default number of folds. 


= Options for the graphical user interface

--check-for-updates <Boolean>  Decide whether or not this program should search for updates at start-up. Default value: true 
--gui                          If this option is given, the program will display its graphical user interface. Default value: false 
--log-level <String>           Change the log-level of this application. 


The p-value thresholds used during the analysis are 1*10^-3 to 1*10^-8 and can
not be changed at the moment.

For simulation parameters, please look at the PLINK website:
http://pngu.mgh.harvard.edu/~purcell/plink/simulate.shtml



External tools
==============

MacLeaps requires the PLINK command line tool executables to be installed on
your system. If they are included in the standard PATH of your system, MacLeaps
will find them. Otherwise, you have to specify the directories that contains the
executables, for example:

java -jar MacLeaps.jar -pp /home/smith/apps/plink/ [options]



Results
=======

The final results you're probably interested in are the AUC values. The pattern
of the result filenames is <studyname>.auc.<kernel>.csv

The files contain the min/avg/max training and validation performance of the SVM
based on different p-value thresholds for the SNPs used to train the model. For
validation, there is also the standard deviation. "count" tells you how many
folds contained at least one SNP. (For strict thresholds, it can happen that
there are no SNPs for some of the k folds, but some SNPs for the others. It
basically tells you, how many models could be trained and used for this AUC
values.)

#training min     avg     max      validation min     avg     max     stdev   count
-5        0.58880 0.58945 0.59010             0.53715 0.55186 0.56656 0.02079 2
-4        0.62660 0.64970 0.67280             0.56922 0.58389 0.59856 0.02075 2
-3        0.71070 0.73095 0.75120             0.63462 0.65039 0.66616 0.02230 2



Examples
========

Example 1:

Let's say you have a GWAS data set located in /data/test.ped (and .map) and want
to perform a 5-fold cross-validation, including the RBF kernel. The results
should go to /results/ with name "experimentA". Then you would start MacLeaps
with

java -jar MacLeaps.jar -p /data/test -s experimentA -o /results/ -k 5 --do-rbf

The final results will be written to /results/experimentA.auc.lin.csv for the
linear SVM and /results/experimentA.auc.rbf.csv for the RBF kernel SVM.

NOTE: If you specify --do-rbf, there are two possibilities:
a) Without the option --normalize, an intensive grid search for parameter
   optimization is performed (may take several hours or days)
b) With the option --normalize, a heuristic is used to determine good parameters
   (takes significantly less time)

Also, if you use normalization, the generated files will contain 'nlin' and
'nrbf' as part of their name to indicate normalization.


Example 2:

Let's say you have a GWAS data set containing two separate cohorts and want to
train a model on one cohort and validate it on the other one, and vice versa.
You need a splitfile containing the individuals of one cohort (e.g. a .fam file)
and you need to specify two studynames, one for the cohort of your splitfile and
one for the rest.

java -jar MacLeaps.jar -p /data/test -sf /data/german.fam -s german/french
 -o /results/ 

The final results will be written into /results/german.auc.lin.csv and
/results/french.auc.lin.csv.


Example 3:

MacLeaps can also use PLINK to generate a simulation data set from a PLINK
simulation configuration file. This file specifies the SNPs to be simulated
(see http://pngu.mgh.harvard.edu/~purcell/plink/simulate.shtml for details).
Other simulation parameters like the number of cases and controls have to be
specified in MacLeaps.

java -jar MacLeaps.jar --sim-file gwas.sim --sim-ncases 500 --sim-ncontrols 500
 --sim-prevalence 0.05 -s simstudy -o /results/ -k 5

This will create a simulation data set with 500 cases and controls each, a
simulated prevalence of 5%. All files will have the prefix "simstudy" and
after generation of the data set, a 5-fold cross-validation will be performed
and the results written to /results/simstudy.auc.lin.csv



Known Issues
============

- Localization is not complete.
  The default language of MacLeaps is English and many labels and messages are
  still hard-coded into the program, so if you use MacLeaps in a different
  language, some strings may still be in English.
  Right now, only English and German are supported, but if you want to
  contribute and add translations for another language, feel free to contact
  us at florian.mittag@uni-tuebingen.de, we'd be very grateful.
  
- Pipeline stage progress bars don't reach 100%.
  We are aware of this and will fix this in a future release. The reason for
  this behavior is that all necessary pipeline steps are initialized at the
  beginning of the analysis and some anticipated steps have to be omitted for
  reasons that could not be known beforehand.
  If you don't see warning messages, everything should be fine.
  

